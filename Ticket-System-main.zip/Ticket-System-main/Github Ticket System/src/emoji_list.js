export default {
    success: "",
    latency: ""
}