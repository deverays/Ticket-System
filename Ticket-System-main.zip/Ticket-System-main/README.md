# Ticket-System
Hello, I want to give you the ticket system that I have used in my own bot. It is a fully customizable and professional ticket system. As for the features of the ticket system, it contains two languages, English and Turkish. If you want to use this bot, it will be enough to download it from the top right. The license belongs to Eray#3664.

![image](https://user-images.githubusercontent.com/129968185/230733157-bd1da825-ab61-4e29-aac3-290a81dec3a5.png)
